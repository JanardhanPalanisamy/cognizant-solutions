
public interface ExternalApi3 {
    String getData();
    String getDataById(int id);
    void saveData(String data, int priority);

}
