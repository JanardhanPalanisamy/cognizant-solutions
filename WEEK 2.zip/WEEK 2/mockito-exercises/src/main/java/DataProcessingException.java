
public class DataProcessingException extends Exception  {
    public DataProcessingException(String message) {
        super(message);
    }

}
